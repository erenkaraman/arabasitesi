﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

public class CLmail
{
    public string mailAdresi = "etmdemo@webdevtasarim.com";
    public string mailSifresi = "Asd123456789***";
    public string nasilGozuksun = "Etm.webdevtasarim.com";
    public int port = 587;
    public int port2 = 143;//mailkit
    public string host = "wing.guzelhosting.com";
    public bool ssl = false;
}
    
